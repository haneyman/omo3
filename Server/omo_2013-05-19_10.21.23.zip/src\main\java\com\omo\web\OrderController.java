package com.omo.web;

import com.omo.domain.MenuItem;
import com.omo.domain.Order;
import com.omo.repository.MenuItemRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

@RequestMapping("/orders")
@Controller
@RooWebScaffold(path = "orders", formBackingObject = Order.class)
public class OrderController {
    private static org.apache.log4j.Logger logger = Logger.getLogger(MenuController.class);

    @Autowired
    MenuItemRepository menuItemRepository;


    @RequestMapping(value = "publicCreate", method = RequestMethod.POST, produces = "text/html")
    public String createOrder(Model uiModel, HttpServletRequest httpServletRequest) {
        logger.debug("createOrder");
/*
        if (bindingResult.hasErrors()) {
            populateEditForm(uiModel, order);
            return "orders/create";
        }
*/
        String menuItemUUID;
        MenuItem menuItem;
        Enumeration enumeration = httpServletRequest.getParameterNames();
        Order order = new Order();
        while (enumeration.hasMoreElements()) {
            String parameterName = (String) enumeration.nextElement();
            logger.debug("Parameter = " + parameterName);
            if (parameterName.contains(MenuItem.MENUITEM_LABEL)) {
                menuItemUUID = parameterName.substring(MenuItem.MENUITEM_LABEL.length() + 2);
                logger.debug("   Menu Item ordered: " + parameterName);
                menuItem = menuItemRepository.findByUuid(menuItemUUID).get(0);
                //order.get

            }
        }
        uiModel.asMap().clear();
        //orderService.saveOrder(order);
        return "public/confirmOrder";
//        return "redirect:/orders/" + encodeUrlPathSegment(order.getId().toString(), httpServletRequest);
    }


}
