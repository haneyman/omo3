package com.omo.services;

        import com.omo.domain.Order;
        import com.omo.service.EmailViaSES;
        import com.omo.service.OrderService;
        import com.omo.service.OrderServiceImpl;
        import org.junit.Before;
        import org.junit.Test;
        import org.junit.runner.RunWith;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.test.context.ContextConfiguration;
        import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
        import org.springframework.test.context.web.WebAppConfiguration;
        import org.springframework.test.web.servlet.MockMvc;
        import org.springframework.web.context.WebApplicationContext;

        import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
        import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
        import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
        import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
//@ContextConfiguration("file:src/main/webapp/WEB-INF/mvc-dispatcher-servlet.xml")
@ContextConfiguration(locations = "classpath:/META-INF/spring/applicationContext*.xml")
public class TestEmail {
    //private MockMvc mockMvc;

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Autowired
    protected WebApplicationContext wac;

    @Before
    public void setup() {
        //this.mockMvc = webAppContextSetup(this.wac).build();
    }

    @Test
    public void simple() throws Exception {
        EmailViaSES.sendEmail("OMO Test subject", "This is the fantastic body", "support@menubreeze.com", "haneyman@yahoo.com");
    }

    @Test
    public void testOrderConfirmation() throws Exception {
        EmailViaSES.sendEmail("OMO Test subject", "This is the fantastic body", "support@menubreeze.com", "mark.haney@johnmuirhealth.com");
        OrderService os = new OrderServiceImpl();
        //Order o = new Order();
        //o.set
        //os.notifyOrder();
    }
}
