package com.omo.domain;

import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.layers.repository.mongo.RooMongoEntity;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooMongoEntity
public class MenuItemOption {

    private String description;

    private Float price;


    public MenuItemOption(Float price, String description) {
        this.description = description;
        this.price = price;
    }
}
